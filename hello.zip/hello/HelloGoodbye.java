/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;

public class HelloGoodbye {
    public static void main(String[] args) {
        if (args.length != 0) {
            StdOut.println("Hello " + args[0] + " and " + args[1]);
            StdOut.println("Goodbye " + args[1] + " and " + args[0]);
        }

    }
}
